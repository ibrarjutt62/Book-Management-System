﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cupboard_Books_Arrangement
{
    public partial class Form3 : Form
    {
         int txtBoxStartPosition = 100;
         int txtBoxStartPositionV = 25;
        public Form3()
        {
            InitializeComponent();
            Label lbl = new Label();
            lbl.Location = new System.Drawing.Point(txtBoxStartPosition, txtBoxStartPositionV);
            lbl.Text = "abc".ToString();
            lbl.ForeColor = System.Drawing.Color.Black;
            this.Controls.Add(lbl);
            txtBoxStartPositionV += 3;
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
