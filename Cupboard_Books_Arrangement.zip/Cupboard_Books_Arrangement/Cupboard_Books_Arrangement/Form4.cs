﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cupboard_Books_Arrangement
{
    public partial class Form4 : Form
    {
        int size = 0;
        public Form4()
        {
            InitializeComponent();
        }
        public Form4(int s)
        {
            InitializeComponent();
            size = s;
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            
            string ch = "";
            string ch1 = "";
            for(int i=0;i<Cupboard.Cupboards.Count();i++)
            {
               /* Label lbl = new Label();
                lbl.Text = "Remaining capacity of Cupboard " + i+1 + " : " + " " + Cupboard.Cupboards[i].Capacity.ToString();
                lbl.ForeColor = System.Drawing.Color.Black;
                lbl.Location = new Point(x, y);
                this.Controls.Add(lbl);*/
                ch += "Remaining capacity of Cupboard " + (i + 1) + " : " + " " + Cupboard.Cupboards[i].Capacity + Environment.NewLine;
                label1.Text = ch;
              
                
            }
            
            for (int j = 0; j < Cupboard.Sortedlist1.Count(); j++)
            {
                if(j>size)
                {
                    ch1 += " Placed As "+ " book " + (Cupboard.Sortedlist1[j].Nbooks)+Environment.NewLine;
                    label2.Text = ch1;
                }
                else
                {
                    ch1 += (Cupboard.Sortedlist1[j].Ncategory) + " book " + (Cupboard.Sortedlist1[j].Nbooks) + Environment.NewLine;
                    label2.Text = ch1;
                }
               
                

            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
