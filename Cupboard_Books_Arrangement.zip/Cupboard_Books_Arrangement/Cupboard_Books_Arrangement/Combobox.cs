﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cupboard_Books_Arrangement
{
    public class Combobox
    {
        public string Text { get; set; }

        public override string ToString()
        {
            return Text;
        }
    }
}
