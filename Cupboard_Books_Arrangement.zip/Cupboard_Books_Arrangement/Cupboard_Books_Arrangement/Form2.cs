﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cupboard_Books_Arrangement
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }
        int s = 0;
        public Form2(int a)
        {

            InitializeComponent();
            s = a;

        }
        private void Test()
        {
            Combobox item = new Combobox();
            for(int i=1;i<=s;i++)
            {
                item.Text = "Category"+i;
                comboBox1.Items.Add(item);  
            }
            
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            Test();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            Cupboard.Infolist.Add(new Cupboard(comboBox1.Text,textBox3.Text));
            MessageBox.Show("Added Sucessfully");
            textBox3.Text = "";
            comboBox1.Text = "";
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
        
            Cupboard.Sortedlist1 = Cupboard.Infolist.OrderBy(o =>Convert.ToInt32(o.Nbooks)).ToList();
            for (int s= 0; s < Cupboard.Sortedlist1.Count(); s++)
            {
                MessageBox.Show(Cupboard.Sortedlist1[s].Ncategory + "," + Cupboard.Sortedlist1[s].Nbooks);
            }
            for (int a = 1; a <= Convert.ToInt32(textBox1.Text); a++)
            {
                Cupboard.Cupboards.Add(new Cupboard(Convert.ToInt32(textBox2.Text)));
            }
            int i = 0, j = 0;
            while (i < Cupboard.Sortedlist1.Count() && j <Cupboard.Cupboards.Count())
            {
                if (Convert.ToInt32(Cupboard.Sortedlist1[i].Nbooks) <= Cupboard.Cupboards[j].Capacity)
                {
                    Cupboard.Cupboards[j].Addbooks(i, Convert.ToInt32(Cupboard.Sortedlist1[i].Nbooks));
                    if (Cupboard.Cupboards[j].Capacity == 0)
                    {
                        j++;
                    }
                    i++;
                }
                else
                //(books[i] >= cupboards[j].capacity);
                {
                    if (Cupboard.Cupboards[j].category.Count() == 0)
                    {
                        int rem = Convert.ToInt32(Cupboard.Sortedlist1[i].Nbooks) - Cupboard.Cupboards[j].Capacity;
                        Cupboard.Cupboards[j].Addbooks(i, Cupboard.Cupboards[j].Capacity);
                        j++;
                        while (rem > 0 && j < Cupboard.Cupboards.Count())
                        {
                            int nrem = rem - Cupboard.Cupboards[j].Capacity;
                            if (nrem < 0)
                            {
                                Cupboard.Cupboards[j].Addbooks(i, rem);
                                j++;
                                rem = 0;
                            }
                            else
                            {
                                int crem = rem - Cupboard.Cupboards[j].Capacity;
                                Cupboard.Cupboards[j].Addbooks(i, rem - crem);
                                j++;
                                rem = crem;
                            }
                        }
                        i++;
                    }
                    else
                    {
                        j++;
                    }
                }
              /*  for (int s = 0; s < Cupboard.Cupboards.Count(); s++)
                {
                    label1.Text = "Remaining capacity of Cupboard " + 1 + " : " + " " + Cupboard.Cupboards[s].Capacity;
                }*/
            }
            Form4 f = new Form4((Cupboard.Infolist.Count() - 1));
            f.Show();
            this.Hide();
       }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
    }
}
