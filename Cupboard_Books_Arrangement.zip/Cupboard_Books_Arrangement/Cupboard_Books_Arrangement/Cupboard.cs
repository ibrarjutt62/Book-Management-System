﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cupboard_Books_Arrangement
{
    class Cupboard
    {
        private int capacity;
        private string ncategory;
        private string nbooks;
        private static List<Cupboard> cupboards = new List<Cupboard>();
        private  static List<int> books = new List<int>();
        public  List<int> category = new List<int>();
        private static List<Cupboard> infolist = new List<Cupboard>();
        private static List<Cupboard> Sortedlist = new List<Cupboard>();
        public Cupboard()
        {

        }
        public Cupboard(string C, string s)
        {
            ncategory = C;
            nbooks = s;

        }
        public int Capacity
        {
            get
            {
                return capacity;
            }

            set
            {
                capacity = value;
            }
        }

        
        public static List<int> Books
        {
            get
            {
                return books;
            }

            set
            {
                books = value;
            }
        }

        internal static List<Cupboard> Cupboards
        {
            get
            {
                return cupboards;
            }

            set
            {
                cupboards = value;
            }
        }

        public  List<int> Category
        {
            get
            {
                return category;
            }

            set
            {
                category = value;
            }
        }

        internal static List<Cupboard> Infolist
        {
            get
            {
                return infolist;
            }

            set
            {
                infolist = value;
            }
        }

        internal static List<Cupboard> Sortedlist1
        {
            get
            {
                return Sortedlist;
            }

            set
            {
                Sortedlist = value;
            }
        }

        public string Ncategory
        {
            get
            {
                return ncategory;
            }

            set
            {
                ncategory = value;
            }
        }

        public string Nbooks
        {
            get
            {
                return nbooks;
            }

            set
            {
                nbooks = value;
            }
        }

        public Cupboard(int c)
        {
            Capacity = c;
        }
      public void Addbooks(int c,int b)
        {
            Capacity = Capacity - b;
            Sortedlist1.Add(new Cupboard(Convert.ToString(c), Convert.ToString(b)));
            category.Add(c);
            Books.Add(b);
        }
       


    }
}
