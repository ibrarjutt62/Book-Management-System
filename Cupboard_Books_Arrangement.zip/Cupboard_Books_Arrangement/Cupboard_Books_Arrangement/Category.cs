﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cupboard_Books_Arrangement
{
    class Category
    {
        private string ncategory;
        private string nbooks;
        private static List<Category> infolist = new List<Category>();
        private  static List<Category> Sortedlist = new List<Category>();
        public Category()
        {

        }
        public Category(string C,string s)
        {
            ncategory = C;
            nbooks = s;
            
        }
        public string Ncategory
        {
            get
            {
                return ncategory;
            }

            set
            {
                ncategory = value;
            }
        }

        public string Nbooks
        {
            get
            {
                return nbooks;
            }

            set
            {
                nbooks = value;
            }
        }

        internal static List<Category> Infolist
        {
            get
            {
                return infolist;
            }

            set
            {
                infolist = value;
            }
        }

        internal static List<Category> Sortedlist1
        {
            get
            {
                return Sortedlist;
            }

            set
            {
                Sortedlist = value;
            }
        }
    }
}
